package assignment2.pattern_match.config;

public class Constants {
    public static final String stringFilePath = "input\\string.txt";
    public static final String patternFilePath = "input\\patterns.txt";
    public static final String outputFilePath = "output\\Output.txt";
    public static final int totalAlphabets = 26;
    public static final int asciiIndexRoot = 65;
}
